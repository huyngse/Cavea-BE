package BirdCage1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BirdCageApplication {

	public static void main(String[] args) {
		SpringApplication.run(BirdCageApplication.class, args);
	}

}
